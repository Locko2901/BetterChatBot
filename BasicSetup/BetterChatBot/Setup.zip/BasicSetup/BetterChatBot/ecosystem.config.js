module.exports = {
    apps : [{
      name: 'ChatBot',
      script: './ChatBot/src/index.js',
    }, {
      name: 'ExampleBot',
      script: './ExampleBot/src/index.js',
    }]
  };